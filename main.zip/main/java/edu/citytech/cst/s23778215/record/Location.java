package edu.citytech.cst.s23778215.record;

public record Location(String code) {
}
