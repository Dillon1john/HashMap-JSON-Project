package edu.citytech.cst.s23778215.record;

public record CustomerPurchase(int _id, String customerId, int totalItems, float totalPrice, ShortDate shortDate, Location location) {

}
