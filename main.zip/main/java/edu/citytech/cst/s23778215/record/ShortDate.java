package edu.citytech.cst.s23778215.record;

public record ShortDate(int year, int month, int day) {
}
